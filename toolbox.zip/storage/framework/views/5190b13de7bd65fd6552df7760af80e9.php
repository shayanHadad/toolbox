<?php $__env->startSection('title', 'شرکت‌ها | جعبه‌ابزار'); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/companies.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


<section class="hero companies-hero">
    <div class="container hero-content">

        <span class="hero-eyebrow"><span class="dot"></span> شرکت‌ها</span>

        <h1>یه <em>شرکت مطمئن</em> برای هر کاری پیدا کن</h1>

        <p>
            توی جعبه‌ابزار می‌تونی بین شرکت‌های حوزه‌های مختلف بگردی، پروفایل و امتیازشون رو ببینی
            و مناسب‌ترین گزینه رو برای کارت انتخاب کنی.
        </p>

        <form method="GET" action="<?php echo e(route('companies.index')); ?>" class="hero-search">
            <?php if(request()->filled('category')): ?>
                <input type="hidden" name="category" value="<?php echo e(request('category')); ?>">
            <?php endif; ?>
            <?php if(request()->filled('sort')): ?>
                <input type="hidden" name="sort" value="<?php echo e(request('sort')); ?>">
            <?php endif; ?>

            <input
                type="text"
                name="q"
                value="<?php echo e(request('q')); ?>"
                placeholder="اسم شرکت، تخصص یا یه کلمه‌ی کلیدی رو بنویس...">

            <button type="submit">جستجو</button>
        </form>

    </div>
</section>


<section class="categories companies-section">
    <div class="container">

        <form method="GET" action="<?php echo e(route('companies.index')); ?>" class="companies-filter-bar">

            <?php if(request()->filled('q')): ?>
                <input type="hidden" name="q" value="<?php echo e(request('q')); ?>">
            <?php endif; ?>

            <div class="filter-field">
                <label for="category">دسته‌بندی</label>
                <select name="category" id="category" onchange="this.form.submit()">
                    <option value="">همه‌ی دسته‌ها</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->url); ?>" <?php echo e(request('category') === $cat->url ? 'selected' : ''); ?>>
                            <?php echo e($cat->category_name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="filter-field">
                <label for="sort">مرتب‌سازی</label>
                <select name="sort" id="sort" onchange="this.form.submit()">
                    <option value="newest" <?php echo e(request('sort', 'newest') === 'newest' ? 'selected' : ''); ?>>جدیدترین</option>
                    <option value="rating" <?php echo e(request('sort') === 'rating' ? 'selected' : ''); ?>>بالاترین امتیاز</option>
                    <option value="orders" <?php echo e(request('sort') === 'orders' ? 'selected' : ''); ?>>پرکارترین</option>
                </select>
            </div>

            <noscript><button type="submit" class="btn btn-outline btn-sm">اعمال فیلتر</button></noscript>

            <?php if(request()->anyFilled(['q', 'category', 'sort'])): ?>
                <a href="<?php echo e(route('companies.index')); ?>" class="filter-clear">✕ پاک کردن فیلترها</a>
            <?php endif; ?>

        </form>

        <?php if(session('success')): ?>
            <div class="companies-flash companies-flash-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <p class="companies-count">
            <?php echo e($companies->total()); ?> شرکت پیدا شد
            <?php if(request()->filled('q')): ?>
                برای «<?php echo e(request('q')); ?>»
            <?php endif; ?>
        </p>

        <div class="company-grid">

            <?php $__empty_1 = true; $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="company-card">

                    <div class="company-card-top">
                        <span class="company-avatar" style="background-image:url('<?php echo e(asset('images/company.png')); ?>')"></span>

                        <?php if($company->categories->isNotEmpty()): ?>
                            <div class="company-badges">
                                <?php $__currentLoopData = $company->categories->take(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="company-badge"><?php echo e($cat->category_name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <h3 class="company-name"><?php echo e($company->name); ?></h3>

                    <div class="company-rating">
                        <?php for($i = 0; $i < 5; $i++): ?>
                            <?php echo e($i < round($company->rating_avg ?? 0) ? '★' : '☆'); ?>

                        <?php endfor; ?>
                        <span class="company-rating-num">
                            <?php echo e($company->rating_avg ? number_format($company->rating_avg, 1) : 'بدون امتیاز'); ?>

                        </span>
                    </div>

                    <p class="company-desc">
                        <?php echo e(\Illuminate\Support\Str::limit($company->descriptions ?: 'این شرکت هنوز توضیحی برای پروفایلش ثبت نکرده.', 110)); ?>

                    </p>

                    <div class="company-card-footer">
                        <span class="company-orders"><?php echo e($company->orders_count); ?> سفارش تمام‌شده</span>

                        <div class="company-card-actions">
                            <a href="<?php echo e(route('companies.show', $company)); ?>" class="btn btn-outline btn-sm">مشاهده پروفایل</a>
                        </div>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="companies-empty">
                    <p>متأسفانه با این فیلترها شرکتی پیدا نشد.</p>
                    <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-outline btn-sm">پاک کردن فیلترها</a>
                </div>
            <?php endif; ?>

        </div>

        <?php if($companies->hasPages()): ?>
            <div class="companies-pagination">
                <?php echo e($companies->onEachSide(1)->links('components.pagination')); ?>

            </div>
        <?php endif; ?>

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/rbt/Documents/0.Daneshgah/Term (8)/Laravel/toolbox/resources/views/companies/index.blade.php ENDPATH**/ ?>