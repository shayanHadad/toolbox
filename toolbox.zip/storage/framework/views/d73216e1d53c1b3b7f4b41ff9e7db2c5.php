<?php $__env->startSection('title', 'ورود'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">

<?php $__env->startSection('content'); ?>
<div class="register-page">
    <div class="login-box">
        <h1>ورود</h1>

        <form method="POST" action="<?php echo e(route('login.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="user-box">
                <input type="text" name="login" value="<?php echo e(old('login')); ?>" required autofocus>
                <label>نام کاربری یا شماره تماس</label>
                <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="user-box">
                <input type="password" name="password" required>
                <label>رمز عبور</label>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button class="btn-submit" type="submit">
                ورود
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </button>
        </form>

        <p class="bottom-text">
            حساب کاربری ندارید؟
            <a class="a2" href="<?php echo e(route('register')); ?>">ثبت‌نام</a>
        </p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/rbt/Documents/0.Daneshgah/Term (8)/Laravel/toolbox/resources/views/auth/login.blade.php ENDPATH**/ ?>