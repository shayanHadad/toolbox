<?php $__env->startSection('title', 'متخصص‌ها | جعبه‌ابزار'); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/experts.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>


<section class="hero experts-hero">
    <div class="container hero-content">

        <span class="hero-eyebrow"><span class="dot"></span> متخصص‌ها</span>

        <h1>یه <em>متخصص مطمئن</em> برای هر کاری پیدا کن</h1>

        <p>
            توی جعبه‌ابزار می‌تونی بین متخصص‌های حوزه‌های مختلف بگردی، پروفایل و امتیازشون رو ببینی
            و مناسب‌ترین گزینه رو برای کارت انتخاب کنی.
        </p>

        <form method="GET" action="<?php echo e(route('experts.index')); ?>" class="hero-search">
            <?php if(request()->filled('category')): ?>
                <input type="hidden" name="category" value="<?php echo e(request('category')); ?>">
            <?php endif; ?>
            <?php if(request()->filled('sort')): ?>
                <input type="hidden" name="sort" value="<?php echo e(request('sort')); ?>">
            <?php endif; ?>

            <input
                type="text"
                name="q"
                value="<?php echo e(request('q')); ?>"
                placeholder="اسم متخصص، تخصص یا یه کلمه‌ی کلیدی رو بنویس...">

            <button type="submit">جستجو</button>
        </form>

    </div>
</section>


<section class="categories experts-section">
    <div class="container">

        <form method="GET" action="<?php echo e(route('experts.index')); ?>" class="experts-filter-bar">

            <?php if(request()->filled('q')): ?>
                <input type="hidden" name="q" value="<?php echo e(request('q')); ?>">
            <?php endif; ?>

            <div class="filter-field">
                <label for="category">دسته‌بندی</label>
                <select name="category" id="category" onchange="this.form.submit()">
                    <option value="">همه‌ی دسته‌ها</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->url); ?>" <?php echo e(request('category') === $cat->url ? 'selected' : ''); ?>>
                            <?php echo e($cat->category_name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="filter-field">
                <label for="sort">مرتب‌سازی</label>
                <select name="sort" id="sort" onchange="this.form.submit()">
                    <option value="newest" <?php echo e(request('sort', 'newest') === 'newest' ? 'selected' : ''); ?>>جدیدترین</option>
                    <option value="rating" <?php echo e(request('sort') === 'rating' ? 'selected' : ''); ?>>بالاترین امتیاز</option>
                    <option value="orders" <?php echo e(request('sort') === 'orders' ? 'selected' : ''); ?>>پرکارترین</option>
                </select>
            </div>

            <noscript><button type="submit" class="btn btn-outline btn-sm">اعمال فیلتر</button></noscript>

            <?php if(request()->anyFilled(['q', 'category', 'sort'])): ?>
                <a href="<?php echo e(route('experts.index')); ?>" class="filter-clear">✕ پاک کردن فیلترها</a>
            <?php endif; ?>

        </form>

        <?php if(session('success')): ?>
            <div class="experts-flash experts-flash-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <p class="experts-count">
            <?php echo e($experts->total()); ?> متخصص پیدا شد
            <?php if(request()->filled('q')): ?>
                برای «<?php echo e(request('q')); ?>»
            <?php endif; ?>
        </p>

        <div class="expert-grid">

            <?php $__empty_1 = true; $__currentLoopData = $experts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="expert-card">

                    <div class="expert-card-top">
                        <span class="expert-avatar" style="background-image:url('<?php echo e(asset('images/expert.png')); ?>')"></span>

                        <?php if($expert->expertDetail?->category): ?>
                            <span class="expert-badge"><?php echo e($expert->expertDetail->category->category_name); ?></span>
                        <?php endif; ?>

                        <?php if(auth()->guard()->check()): ?>
                            <?php if(auth()->user()->role == 1): ?>
                                <form action="<?php echo e(route('bookmarks.toggle', $expert)); ?>" method="POST" class="btn-icon-form">
                                    <?php echo csrf_field(); ?>
                                    <?php $isBookmarked = in_array($expert->userID, $bookmarkedIds); ?>
                                    <button
                                        type="submit"
                                        class="btn-icon <?php echo e($isBookmarked ? 'btn-icon-active' : ''); ?>"
                                        title="<?php echo e($isBookmarked ? 'حذف از بوکمارک‌ها' : 'بوکمارک کردن این متخصص'); ?>">
                                        <img src="<?php echo e(asset('images/bookmark-icon.png')); ?>" alt="بوکمارک">
                                    </button>
                                </form>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>

                    <h3 class="expert-name"><?php echo e(trim($expert->first_name . ' ' . $expert->last_name)); ?></h3>

                    <div class="expert-rating">
                        <?php for($i = 0; $i < 5; $i++): ?>
                            <?php echo e($i < round($expert->rating_avg ?? 0) ? '★' : '☆'); ?>

                        <?php endfor; ?>
                        <span class="expert-rating-num">
                            <?php echo e($expert->rating_avg ? number_format($expert->rating_avg, 1) : 'بدون امتیاز'); ?>

                        </span>
                    </div>

                    <p class="expert-desc">
                        <?php echo e(\Illuminate\Support\Str::limit($expert->expertDetail?->description ?: 'این متخصص هنوز توضیحی برای پروفایلش ثبت نکرده.', 110)); ?>

                    </p>

                    <div class="expert-card-footer">
                        <span class="expert-orders"><?php echo e($expert->orders_count); ?> سفارش تمام‌شده</span>

                        <div class="expert-card-actions">
                            <?php if(auth()->guard()->check()): ?>
                                <?php if(auth()->user()->role == 1): ?>
                                    <a href="<?php echo e(route('messages.show', $expert)); ?>" class="btn btn-outline btn-sm">
                                        ارسال پیام
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                            <a href="<?php echo e(route('experts.show', $expert)); ?>" class="btn btn-outline btn-sm">مشاهده پروفایل</a>
                        </div>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="experts-empty">
                    <p>متأسفانه با این فیلترها متخصصی پیدا نشد.</p>
                    <a href="<?php echo e(route('experts.index')); ?>" class="btn btn-outline btn-sm">پاک کردن فیلترها</a>
                </div>
            <?php endif; ?>

        </div>

        <?php if($experts->hasPages()): ?>
            <div class="experts-pagination">
                <?php echo e($experts->onEachSide(1)->links('components.pagination')); ?>

            </div>
        <?php endif; ?>

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/rbt/Documents/0.Daneshgah/Term (8)/Laravel/toolbox/resources/views/experts/index.blade.php ENDPATH**/ ?>