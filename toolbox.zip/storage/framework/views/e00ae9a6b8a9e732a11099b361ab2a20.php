<?php $__env->startSection('title', 'گفتگو با ' . trim($partner->first_name . ' ' . $partner->last_name) . ' | جعبه‌ابزار'); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/experts.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section class="categories experts-section">
    <div class="container">

        <a href="<?php echo e(route('messages.index')); ?>" class="expert-back-link">→ بازگشت به پیام‌ها</a>

        <?php if(session('success')): ?>
            <div class="experts-flash experts-flash-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <div class="t-card chat-wrap">

            <div class="chat-header">
                <span class="expert-avatar" style="background-image:url('<?php echo e(asset($partner->role == 2 ? 'images/expert.png' : 'images/default-pfp.png')); ?>')"></span>

                <div>
                    <p class="chat-header-name"><?php echo e(trim($partner->first_name . ' ' . $partner->last_name)); ?></p>
                    <?php if($partner->role == 2 && $partner->expertDetail): ?>
                        <a href="<?php echo e(route('experts.show', $partner)); ?>" class="chat-header-link">مشاهده پروفایل متخصص</a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="chat-messages">
                <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php $isMine = $message->senderID == auth()->id(); ?>
                    <div class="chat-bubble-row <?php echo e($isMine ? 'chat-bubble-row-mine' : ''); ?>">
                        <div class="chat-bubble <?php echo e($isMine ? 'chat-bubble-mine' : 'chat-bubble-theirs'); ?>">
                            <p class="chat-bubble-text"><?php echo e($message->message); ?></p>
                            <span class="chat-bubble-meta">
                                <span class="chat-bubble-time"><?php echo e($message->created_at?->format('Y-m-d H:i')); ?></span>
                                <?php if($isMine): ?>
                                    <span class="chat-tick <?php echo e($message->status == 1 ? 'chat-tick-read' : ''); ?>" title="<?php echo e($message->status == 1 ? 'دیده شده' : 'ارسال شده'); ?>">
                                        <?php echo e($message->status == 1 ? '✓✓' : '✓'); ?>

                                    </span>
                                <?php endif; ?>
                            </span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="t-text" style="text-align:center;">هنوز پیامی بین شما رد و بدل نشده.</p>
                <?php endif; ?>
            </div>

            <?php if(auth()->guard()->check()): ?>
                <?php if(in_array(auth()->user()->role, [1, 2])): ?>
                    <form action="<?php echo e(route('messages.store', $partner)); ?>" method="POST" class="chat-form">
                        <?php echo csrf_field(); ?>
                        <textarea
                            name="message"
                            class="chat-textarea"
                            rows="3"
                            maxlength="2000"
                            placeholder="پیامت رو اینجا بنویس..."
                            required></textarea>

                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="cd-error"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <button type="submit" class="btn btn-primary btn-sm">ارسال پیام</button>
                    </form>
                <?php endif; ?>
            <?php endif; ?>

        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/rbt/Documents/0.Daneshgah/Term (8)/Laravel/toolbox/resources/views/messages/show.blade.php ENDPATH**/ ?>