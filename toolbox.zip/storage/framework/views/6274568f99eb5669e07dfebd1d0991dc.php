<nav class="navbar">
    <input type="checkbox" id="nav-toggle" class="nav-toggle">

    <div class="nav-container">

        <!-- Logo -->
        <div class="logo">
            <a href="<?php echo e(url('/')); ?>" title="بازگشت به صفحه اصلی">
                <img src="<?php echo e(asset('images/logo.png')); ?>"
                    alt="جعبه‌ابزار لوگو"
                    loading="lazy"
                    height="40">
                <span>جعبه‌ابزار</span>
            </a>
        </div>

        <!-- Desktop Navigation -->
        <ul class="nav-center">

            <li>
                <a href="<?php echo e(url('/')); ?>">
                    <i>🏠</i>
                    <span>خانه</span>
                </a>
            </li>

            <li>
                <a href="<?php echo e(url('/experts')); ?>">
                    <i>🛠️</i>
                    <span>متخصص‌ها</span>
                </a>
            </li>

            <li>
                <a href="<?php echo e(route('companies.index')); ?>">
                    <i>🏢</i>
                    <span>شرکت‌ها</span>
                </a>
            </li>

            <li>
                <a href="<?php echo e(url('/about')); ?>">
                    <i>❓</i>
                    <span>درباره ما</span>
                </a>
            </li>

            <li>
                <a href="<?php echo e(url('/contact')); ?>">
                    <i>📞</i>
                    <span>تماس با ما</span>
                </a>
            </li>

        </ul>

        <!-- Right Side -->
        <div class="nav-left">

            <?php if(auth()->guard()->guest()): ?>
            <a href="<?php echo e(route('login')); ?>" class="btn btn-outline btn-sm">
                ورود
            </a>

            <a href="<?php echo e(route('register')); ?>" class="btn btn-primary btn-sm">
                ثبت‌نام
            </a>
            <?php endif; ?>

            <?php if(auth()->guard()->check()): ?>
            <form method="POST" action="<?php echo e(route('logout')); ?>" class="nav-logout-form">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-outline btn-sm">
                    خروج
                </button>
            </form>
            <a href="<?php echo e(route(auth()->user()->dashboardRoute())); ?>#profile-form" class="nav-profile-link" title="داشبورد کاربری">
                <img src="<?php echo e(asset(auth()->user()->role == 2 ? 'images/expert.png' : 'images/default-pfp.png')); ?>" alt="پروفایل کاربری" class="nav-profile-img">
                <span class="nav-profile-name"><?php echo e(auth()->user()->first_name); ?> <?php echo e(auth()->user()->last_name); ?></span>
            </a>
            <?php endif; ?>
            <label class="nav-burger" for="nav-toggle" aria-label="باز کردن منو">
                <span></span>
            </label>

        </div>

    </div>

    <!-- Mobile Navigation -->

    <ul class="nav-mobile-panel">
        <li>
            <a href="<?php echo e(url('/')); ?>">
                🏠 خانه
            </a>
        </li>

        <li>
            <a href="<?php echo e(url('/experts')); ?>">
                🛠️ متخصص‌ها
            </a>
        </li>

        <li>
            <a href="<?php echo e(route('companies.index')); ?>">
                🏢 شرکت‌ها
            </a>
        </li>

        <li>
            <a href="<?php echo e(url('/about')); ?>">
                🧰 درباره ما
            </a>
        </li>

        <li>
            <a href="<?php echo e(url('/contact')); ?>">
                📞 تماس با ما
            </a>
        </li>

        <li class="nav-mobile-actions">
            <?php if(auth()->guard()->guest()): ?>
            <a href="<?php echo e(route('login')); ?>" class="btn btn-outline">
                ورود
            </a>

            <a href="<?php echo e(route('register')); ?>" class="btn btn-primary">
                ثبت‌نام
            </a>
            <?php endif; ?>

            <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route(auth()->user()->dashboardRoute())); ?>#profile-form" class="btn btn-outline">
                <img src="<?php echo e(asset(auth()->user()->role == 2 ? 'images/expert.png' : 'images/default-pfp.png')); ?>" alt="پروفایل کاربری" class="nav-profile-img-mobile">
                داشبورد
            </a>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-primary">
                    خروج
                </button>
            </form>
            <?php endif; ?>
        </li>
    </ul>

</nav><?php /**PATH /home/rbt/Documents/0.Daneshgah/Term (8)/Laravel/toolbox/resources/views/components/navbar.blade.php ENDPATH**/ ?>