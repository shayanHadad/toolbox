
<?php if(auth()->guard()->check()): ?>
<?php if(auth()->user()->role == 1): ?>
<div class="message-modal-backdrop" id="message-modal" aria-hidden="true">
    <div class="message-modal" role="dialog" aria-modal="true" aria-labelledby="message-modal-title">

        <button type="button" class="message-modal-close" id="message-modal-close" aria-label="بستن">✕</button>

        <h3 class="message-modal-title" id="message-modal-title">
            ارسال پیام به <span id="message-modal-name"></span>
        </h3>

        <form id="message-modal-form" method="POST" action="">
            <?php echo csrf_field(); ?>
            <textarea
                name="message"
                id="message-modal-textarea"
                class="message-modal-textarea"
                rows="5"
                maxlength="2000"
                placeholder="پیامت رو اینجا بنویس..."
                required></textarea>

            <button type="submit" class="btn btn-primary btn-sm">ارسال پیام</button>
        </form>

    </div>
</div>

<script src="<?php echo e(asset('js/message-modal .js')); ?>"></script>
<?php endif; ?>
<?php endif; ?><?php /**PATH /home/rbt/Documents/0.Daneshgah/Term (8)/Laravel/toolbox/resources/views/components/message-modal.blade.php ENDPATH**/ ?>