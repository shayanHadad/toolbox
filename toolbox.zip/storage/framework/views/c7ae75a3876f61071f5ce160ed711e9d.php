<?php $__env->startSection('title', $company->name . ' | جعبه‌ابزار'); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/companies.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section class="categories company-profile">
    <div class="container">

        <a href="<?php echo e(route('companies.index')); ?>" class="company-back-link">→ بازگشت به لیست شرکت‌ها</a>

        <?php if(session('success')): ?>
            <div class="companies-flash companies-flash-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <div class="company-profile-grid">

            <div class="t-card company-profile-main">

                <div class="company-profile-head">
                    <span class="company-avatar company-avatar-lg" style="background-image:url('<?php echo e(asset('images/company.png')); ?>')"></span>

                    <div>
                        <h1 class="company-profile-name"><?php echo e($company->name); ?></h1>

                        <?php if($company->categories->isNotEmpty()): ?>
                            <div class="company-badges">
                                <?php $__currentLoopData = $company->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="company-badge"><?php echo e($cat->category_name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>

                        <div class="company-rating">
                            <?php for($i = 0; $i < 5; $i++): ?>
                                <?php echo e($i < round($company->rating_avg ?? 0) ? '★' : '☆'); ?>

                            <?php endfor; ?>
                            <span class="company-rating-num">
                                <?php echo e($company->rating_avg ? number_format($company->rating_avg, 1) : 'بدون امتیاز'); ?>

                            </span>
                        </div>
                    </div>
                </div>

                <h2 class="company-section-title">درباره‌ی شرکت</h2>
                <p class="company-desc-full">
                    <?php echo e($company->descriptions ?: 'این شرکت هنوز توضیحی برای پروفایلش ثبت نکرده.'); ?>

                </p>

                <?php if($company->founding_date): ?>
                    <h2 class="company-section-title">تاریخ تأسیس</h2>
                    <p class="company-desc-full"><?php echo e($company->founding_date->format('Y/m/d')); ?></p>
                <?php endif; ?>

            </div>

            <div class="company-profile-side">

                <div class="t-card">
                    <h2 class="company-section-title">نظرات مشتری‌ها</h2>

                    <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="company-review">
                            <div class="t-stars">
                                <?php for($i = 0; $i < 5; $i++): ?>
                                    <?php echo e($i < $order->rating ? '★' : '☆'); ?>

                                <?php endfor; ?>
                            </div>
                            <p class="t-text"><?php echo e($order->comment); ?></p>
                            <span class="t-name"><?php echo e($order->customer->first_name ?? 'کاربر'); ?> <?php echo e($order->customer->last_name ?? ''); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="t-text">هنوز نظری برای این شرکت ثبت نشده.</p>
                    <?php endif; ?>
                </div>

            </div>

        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/rbt/Documents/0.Daneshgah/Term (8)/Laravel/toolbox/resources/views/companies/show.blade.php ENDPATH**/ ?>