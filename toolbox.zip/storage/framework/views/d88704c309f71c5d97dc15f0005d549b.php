<?php $__env->startSection('title', 'تماس با ما'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/contact.css')); ?>">


<?php $__env->startSection('content'); ?>

<section class="contact-hero">
    <div class="container hero-content">
        <div class="hero-eyebrow">
            <span class="dot"></span>
            تماس با ما
        </div>

        <h1>سوالی داری؟ <em>خوشحال می‌شیم</em> کمکت کنیم</h1>

        <p>
            برای هر سوال، پیشنهاد یا مشکلی که داری، فرم زیر رو پر کن یا از راه‌های ارتباطی دیگه با ما در تماس باش.
        </p>
    </div>
</section>

<section class="categories">
    <div class="container contact-container">

        <div class="contact-grid">

            <div class="t-card contact-form-card">

                <h2 class="contact-title">فرم تماس</h2>

                <?php if(session('status')): ?>
                <p class="contact-success"><?php echo e(session('status')); ?></p>
                <?php endif; ?>

                <?php if(session('error')): ?>
                <p class="contact-error"><?php echo e(session('error')); ?></p>
                <?php endif; ?>

                <form method="POST"
                    action="<?php echo e(route('contact.send')); ?>"
                    class="contact-form">

                    <?php echo csrf_field(); ?>

                    <div>

                        <label class="contact-label">
                            نام و نام خانوادگی
                        </label>

                        <input
                            type="text"
                            value="<?php echo e(auth()->check() ? trim(auth()->user()->first_name . ' ' . auth()->user()->last_name) : old('name')); ?>" <?php if(auth()->guard()->check()): ?> readonly <?php endif; ?>
                            required
                            class="contact-input <?php echo e(auth()->check() ? 'readonly-input' : ''); ?>">

                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="field-error"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div>

                        <label class="contact-label">
                            ایمیل
                        </label>

                        <input
                            type="email"
                            name="email"
                            value="<?php echo e(old('email')); ?>"
                            required
                            class="contact-input"
                            placeholder="example@gmail.com">


                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="field-error"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <div>

                        <label class="contact-label">
                            موضوع
                        </label>

                        <input
                            type="text"
                            name="subject"
                            value="<?php echo e(old('subject')); ?>"
                            class="contact-input">

                    </div>

                    <div>

                        <label class="contact-label">
                            پیام
                        </label>

                        <textarea
                            name="message"
                            rows="5"
                            required
                            class="contact-textarea"><?php echo e(old('message')); ?></textarea>

                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="field-error"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>

                    <?php if(auth()->guard()->guest()): ?>

                    <div class="login-required">

                        <p class="t-text">
                            برای ارسال فرم تماس باید ابتدا وارد حساب کاربری‌ت بشی.
                        </p>

                        <a href="<?php echo e(route('login')); ?>"
                            class="btn btn-primary btn-sm">
                            ورود به حساب کاربری
                        </a>

                    </div>

                    <?php else: ?>

                    <button
                        type="submit"
                        class="btn btn-primary contact-submit">
                        ارسال پیام
                    </button>

                    <?php endif; ?>

                </form>

            </div>

            <div class="contact-info">

                <div class="t-card">
                    <div class="t-name info-title">ایمیل</div>
                    <p class="t-text">info@toolbox.example</p>
                </div>

                <div class="t-card">
                    <div class="t-name info-title">تلفن</div>
                    <p class="t-text">۰۲۱-۱۲۳۴۵۶۷۸</p>
                </div>

                <div class="t-card">
                    <div class="t-name info-title">آدرس</div>
                    <p class="t-text">تهران، خیابان ولیعصر، برج تولباکس</p>
                </div>

            </div>

        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/rbt/Documents/0.Daneshgah/Term (8)/Laravel/toolbox/resources/views/contact.blade.php ENDPATH**/ ?>