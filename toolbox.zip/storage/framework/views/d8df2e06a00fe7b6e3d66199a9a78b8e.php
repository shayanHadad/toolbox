<?php $__env->startSection('title', 'ثبت نام'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/register.css')); ?>">


<?php $__env->startSection('content'); ?>

    <div class="register-page">

        <div class="login-box">

            <h1>ثبت نام</h1>

            <form action="<?php echo e(route('register.store')); ?>" method="POST">

                <?php echo csrf_field(); ?>

                
                <div class="user-box">
                    <input type="text" name="username" value="<?php echo e(old('username')); ?>" required>
                    <label>نام کاربری</label>
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="user-box">
                    <input type="text" name="first_name" value="<?php echo e(old('first_name')); ?>" required>
                    <label>نام</label>
                </div>

                
                <div class="user-box">
                    <input type="tel" name="contact_number" value="<?php echo e(old('contact_number')); ?>" required>
                    <label>شماره موبایل</label>
                    <?php $__errorArgs = ['contact_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger">
                            <?php echo e($message); ?>

                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                
                <div class="user-box">

                    <select name="role" required>

                        <option value="">انتخاب نقش</option>

                        <option value="1" <?php echo e(old('role') == 1 ? 'selected' : ''); ?>>
                            مشتری
                        </option>

                        <option value="2" <?php echo e(old('role') == 2 ? 'selected' : ''); ?>>
                            متخصص
                        </option>

                        <!-- <option value="3" <?php echo e(old('role') == 3 ? 'selected' : ''); ?>>
                            شرکت
                        </option> -->

                    </select>

                    <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                
                <div class="user-box">
                    <input type="date" name="date_of_birth" value="<?php echo e(old('date_of_birth')); ?>">

                    <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                
                <div class="user-box">
                    <input type="password" name="password" required>
                    <label>رمز عبور</label>

                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button class="btn-submit" type="submit">

                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    ثبت‌نام
                </button>

            </form>

            <div class="bottom-text">

                قبلاً ثبت نام کرده‌اید؟

                <a class="a2" href="<?php echo e(route('login')); ?>">
                    ورود
                </a>

            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<script src="<?php echo e(asset('js/register.js')); ?>"></script>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/rbt/Documents/0.Daneshgah/Term (8)/Laravel/toolbox/resources/views/auth/register.blade.php ENDPATH**/ ?>