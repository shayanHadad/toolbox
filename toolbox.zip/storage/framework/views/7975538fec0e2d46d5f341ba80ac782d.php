<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Toolbox'); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>
    <?php echo $__env->make('components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php if(auth()->guard()->check()): ?>


    <div class="floating-actions">
        <a href="<?php echo e(route(auth()->user()->dashboardRoute())); ?>" class="floating-btn" title="داشبورد">
            <img src="<?php echo e(asset('images/dashboard-icon.png')); ?>" alt="داشبورد" class="floating-btn-icon">
            <span class="floating-btn-label">داشبورد</span>
        </a>

        <a href="<?php echo e(route('messages.index')); ?>" class="floating-btn" title="پیام‌ها">
            <img src="<?php echo e(asset('images/message-icon.png')); ?>" alt="پیام‌ها" class="floating-btn-icon">
            <span class="floating-btn-label">پیام‌ها</span>
        </a>

       <?php if(auth()->user()->isCustomer()): ?>
    <a href="<?php echo e(route('bookmarks.index')); ?>" class="floating-btn" title="بوکمارک‌ها">
        <img src="<?php echo e(asset('images/bookmark-icon.png')); ?>" alt="بوکمارک‌ها" class="floating-btn-icon">
        <span class="floating-btn-label">بوکمارک‌ها</span>
    </a>
<?php endif; ?>
    </div>
    <?php endif; ?>

    <main class="page-bg">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <?php echo $__env->make('components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <button type="button" class="back-to-top" id="back-to-top" aria-label="برو به بالای صفحه">↑</button>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>

</html>
<?php /**PATH /home/rbt/Documents/0.Daneshgah/Term (8)/Laravel/toolbox/resources/views/layouts/app.blade.php ENDPATH**/ ?>