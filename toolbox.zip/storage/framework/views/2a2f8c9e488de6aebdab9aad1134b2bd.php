<?php $__env->startSection('title', 'پنل شرکت | جعبه‌ابزار'); ?>

<?php $__env->startSection('content'); ?>

<section class="categories">
    <div class="container" style="display:flex; justify-content:center; padding-top:60px; padding-bottom:60px;">

        <div class="t-card" style="max-width:520px; width:100%; text-align:center; padding:48px 32px; display:flex; flex-direction:column; align-items:center; gap:16px;">

            <span style="font-size:42px;">🚧</span>

            <h1 style="font-size:20px; font-weight:800; color:var(--ink);">
                پنل کاربری شرکت‌ها در حال ساخت است
            </h1>

            <p style="font-size:14.5px; line-height:1.9; color:var(--text-light);">
                سلام <?php echo e($user->first_name ?? 'همراه عزیز'); ?>؛ این بخش از سایت هنوز طراحی و پیاده‌سازی نشده و
                به‌زودی در دسترس قرار می‌گیره. ممنون از صبوری‌ات 🙏
            </p>

            <a href="<?php echo e(url('/')); ?>" class="btn btn-primary btn-sm">بازگشت به صفحه‌ی اصلی</a>

        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/rbt/Documents/0.Daneshgah/Term (8)/Laravel/toolbox/resources/views/dashboard/company.blade.php ENDPATH**/ ?>