<?php if($paginator->hasPages()): ?>
    <nav class="pagination-nav" aria-label="صفحه‌بندی">

        <?php if($paginator->onFirstPage()): ?>
            <span class="page-link page-disabled">قبلی</span>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="page-link">قبلی</a>
        <?php endif; ?>

        <?php
            // این عدد باید با ->onEachSide(...) که موقع صدا زدن links() پاس می‌دی هماهنگ باشه
            $onEachSide = 1;
            $start = max(1, $paginator->currentPage() - $onEachSide);
            $end   = min($paginator->lastPage(), $paginator->currentPage() + $onEachSide);
        ?>

        <?php if($start > 1): ?>
            <a href="<?php echo e($paginator->url(1)); ?>" class="page-link">1</a>
            <?php if($start > 2): ?>
                <span class="page-link page-dots">…</span>
            <?php endif; ?>
        <?php endif; ?>

        <?php $__currentLoopData = $paginator->getUrlRange($start, $end); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($page == $paginator->currentPage()): ?>
                <span class="page-link page-active"><?php echo e($page); ?></span>
            <?php else: ?>
                <a href="<?php echo e($url); ?>" class="page-link"><?php echo e($page); ?></a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($end < $paginator->lastPage()): ?>
            <?php if($end < $paginator->lastPage() - 1): ?>
                <span class="page-link page-dots">…</span>
            <?php endif; ?>
            <a href="<?php echo e($paginator->url($paginator->lastPage())); ?>" class="page-link"><?php echo e($paginator->lastPage()); ?></a>
        <?php endif; ?>

        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="page-link">بعدی</a>
        <?php else: ?>
            <span class="page-link page-disabled">بعدی</span>
        <?php endif; ?>

    </nav>
<?php endif; ?>
<?php /**PATH /home/rbt/Documents/0.Daneshgah/Term (8)/Laravel/toolbox/resources/views/components/pagination.blade.php ENDPATH**/ ?>