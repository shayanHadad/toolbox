<?php $__env->startSection('title', 'بوکمارک‌های من | جعبه‌ابزار'); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/experts.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section class="categories experts-section">
    <div class="container">

        <h1 class="expert-section-title" style="margin-bottom:20px;">بوکمارک‌های من</h1>

        <?php if(session('success')): ?>
            <div class="experts-flash experts-flash-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <div class="expert-grid bookmarks-grid">

            <?php $__empty_1 = true; $__currentLoopData = $providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="expert-card">

                    <div class="expert-card-top">
                        <span class="expert-avatar" style="background-image:url('<?php echo e(asset('images/default-pfp.png')); ?>')"></span>

                        <?php if($provider->expertDetail?->category): ?>
                            <span class="expert-badge"><?php echo e($provider->expertDetail->category->category_name); ?></span>
                        <?php endif; ?>
                    </div>

                    <h3 class="expert-name"><?php echo e(trim($provider->first_name . ' ' . $provider->last_name)); ?></h3>

                    <p class="expert-desc">
                        <?php echo e(\Illuminate\Support\Str::limit($provider->expertDetail?->description ?: 'این متخصص هنوز توضیحی برای پروفایلش ثبت نکرده.', 110)); ?>

                    </p>

                    <div class="expert-card-footer">
                        <form action="<?php echo e(route('bookmarks.toggle', $provider)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn-icon btn-icon-active" title="حذف از بوکمارک‌ها">
                                <img src="<?php echo e(asset('images/bookmark-icon.png')); ?>" alt="بوکمارک">
                            </button>
                        </form>
                        <a href="<?php echo e(route('experts.show', $provider)); ?>" class="btn btn-outline btn-sm">مشاهده پروفایل</a>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="experts-empty">
                    <p>هنوز هیچ متخصصی رو بوکمارک نکردی.</p>
                    <a href="<?php echo e(route('experts.index')); ?>" class="btn btn-outline btn-sm">رفتن به لیست متخصص‌ها</a>
                </div>
            <?php endif; ?>

        </div>

        <?php if($providers->hasPages()): ?>
            <div class="experts-pagination">
                <?php echo e($providers->onEachSide(1)->links('components.pagination')); ?>

            </div>
        <?php endif; ?>

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/rbt/Documents/0.Daneshgah/Term (8)/Laravel/toolbox/resources/views/bookmarks/index.blade.php ENDPATH**/ ?>