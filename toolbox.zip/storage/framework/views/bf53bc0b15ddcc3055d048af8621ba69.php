<?php $__env->startSection('title', trim($expert->first_name . ' ' . $expert->last_name) . ' | جعبه‌ابزار'); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/experts.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section class="categories expert-profile">
    <div class="container">

        <a href="<?php echo e(route('experts.index')); ?>" class="expert-back-link">→ بازگشت به لیست متخصص‌ها</a>

        <?php if(session('success')): ?>
            <div class="experts-flash experts-flash-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <div class="expert-profile-grid">

            <div class="t-card expert-profile-main">

                <div class="expert-profile-head">
                    <span class="expert-avatar expert-avatar-lg" style="background-image:url('<?php echo e(asset('images/expert.png')); ?>')"></span>

                    <div>
                        <h1 class="expert-profile-name"><?php echo e(trim($expert->first_name . ' ' . $expert->last_name)); ?></h1>

                        <?php if($expert->expertDetail?->category): ?>
                            <span class="expert-badge"><?php echo e($expert->expertDetail->category->category_name); ?></span>
                        <?php endif; ?>

                        <div class="expert-rating">
                            <?php for($i = 0; $i < 5; $i++): ?>
                                <?php echo e($i < round($expert->rating_avg ?? 0) ? '★' : '☆'); ?>

                            <?php endfor; ?>
                            <span class="expert-rating-num">
                                <?php echo e($expert->rating_avg ? number_format($expert->rating_avg, 1) : 'بدون امتیاز'); ?>

                            </span>
                        </div>
                    </div>

                    <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->user()->role == 1): ?>
                            <div class="expert-profile-actions">
                                <form action="<?php echo e(route('bookmarks.toggle', $expert)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button
                                        type="submit"
                                        class="btn btn-outline btn-sm <?php echo e($isBookmarked ? 'btn-icon-active' : ''); ?>">
                                        <img src="<?php echo e(asset('images/bookmark-icon.png')); ?>" alt="" class="btn-inline-icon">
                                        <?php echo e($isBookmarked ? 'حذف بوکمارک' : 'بوکمارک کردن'); ?>

                                    </button>
                                </form>

                                <a
                                    href="<?php echo e(route('messages.show', $expert)); ?>"
                                    class="btn btn-primary btn-sm">
                                    <img src="<?php echo e(asset('images/message-icon.png')); ?>" alt="" class="btn-inline-icon">
                                    ارسال پیام
                                </a>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>

                <h2 class="expert-section-title">درباره‌ی من</h2>
                <p class="expert-desc-full">
                    <?php echo e($expert->expertDetail?->description ?: 'این متخصص هنوز توضیحی برای پروفایلش ثبت نکرده.'); ?>

                </p>

                <?php if($expert->expertDetail?->resume): ?>
                    <h2 class="expert-section-title">رزومه</h2>
                    <p class="expert-desc-full"><?php echo e($expert->expertDetail->resume); ?></p>
                <?php endif; ?>

            </div>

            <div class="expert-profile-side">

                <div class="t-card">
                    <h2 class="expert-section-title">نظرات مشتری‌ها</h2>

                    <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="expert-review">
                            <div class="t-stars">
                                <?php for($i = 0; $i < 5; $i++): ?>
                                    <?php echo e($i < $order->rating ? '★' : '☆'); ?>

                                <?php endfor; ?>
                            </div>
                            <p class="t-text"><?php echo e($order->comment); ?></p>
                            <span class="t-name"><?php echo e($order->customer->first_name ?? 'کاربر'); ?> <?php echo e($order->customer->last_name ?? ''); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="t-text">هنوز نظری برای این متخصص ثبت نشده.</p>
                    <?php endif; ?>
                </div>

            </div>

        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/rbt/Documents/0.Daneshgah/Term (8)/Laravel/toolbox/resources/views/experts/show.blade.php ENDPATH**/ ?>