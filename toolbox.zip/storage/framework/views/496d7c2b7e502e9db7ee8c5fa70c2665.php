<?php $__env->startSection('title', 'Toolbox'); ?>

<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="<?php echo e(asset('css/dashboard/customer.css')); ?>">

<div class="cd-wrap">

    
    <div class="cd-header">
        <div class="cd-header-left">
            <img src="<?php echo e(asset('images/default-pfp.png')); ?>" alt="<?php echo e($user->first_name); ?>" class="cd-avatar">
            <div>
                <p class="cd-eyebrow"><?php echo e($user->username); ?></p>
                <p class="cd-name"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></p>
            </div>
        </div>
        <a href="#profile-form" class="cd-btn"> ویرایش اطلاعات پروفایل </a>
    </div>

    
    <div class="cd-stats">
        <div class="cd-stat">
            <p class="cd-stat-label">سفارش‌های ناتمام</p>
            <p class="cd-stat-value" style="color:#3E8E7E"><?php echo e($stats['active']); ?></p>
        </div>
        <div class="cd-stat">
            <p class="cd-stat-label">سفارش‌های به اتمام رسیده</p>
            <p class="cd-stat-value" style="color:#C9A24B"><?php echo e($stats['completed']); ?></p>
        </div>
        <div class="cd-stat">
            <p class="cd-stat-label">پیام‌های خوانده نشده</p>
            <p class="cd-stat-value" style="color:#C4573B"><?php echo e($stats['unread']); ?></p>
        </div>
    </div>

    <div class="cd-grid">

        
        <div class="cd-card">
            <div class="cd-card-head">
                <p class="cd-card-title">سفارش‌های اخیر</p>
                <a href="#" class="cd-link">مشاهده همه</a>
            </div>

            <?php
            $stageKeys = ['waiting', 'in_progress', 'finished'];
            $stageLabels = ['waiting' => 'در حال انتظار', 'in_progress' => 'در جریان', 'finished' => 'تمام شده'];
            ?>

            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
            $currentIndex = array_search($order->status, $stageKeys);
            $badgeClass = match($order->status) {
            'waiting' => 'cd-badge-waiting',
            'in_progress' => 'cd-badge-progress',
            'finished' => 'cd-badge-done',
            default => 'cd-badge-waiting',
            };
            ?>
            <div class="cd-order">
                <div class="cd-order-top">
                    <div>
                        <p class="cd-order-name"><?php echo e($order->provider->first_name ?? 'Provider'); ?> <?php echo e($order->provider->last_name ?? ''); ?></p>
                        <p class="cd-order-meta">
                            Order #<?php echo e($order->orderID); ?>

                            <?php if($order->order_date): ?>
                            · <?php echo e(\Carbon\Carbon::parse($order->order_date)->format('M j, Y')); ?>

                            <?php endif; ?>
                        </p>
                    </div>
                    <span class="cd-badge <?php echo e($badgeClass); ?>"><?php echo e($stageLabels[$order->status] ?? ucfirst($order->status)); ?></span>
                </div>
                <div class="cd-stepper">
                    <?php $__currentLoopData = $stageKeys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="cd-node <?php echo e($i < $currentIndex ? 'done' : ($i === $currentIndex ? 'current' : '')); ?>"></div>
                    <?php if(!$loop->last): ?>
                    <div class="cd-track <?php echo e($i < $currentIndex ? 'done' : ''); ?>"></div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="cd-empty">
                <p>هنوز سفارشی ندارید</p>
            </div>
            <?php endif; ?>
        </div>

        
        <div class="cd-side">

            <div class="cd-card">
                <div class="cd-card-head">
                    <p class="cd-card-title">بوکمارک‌ها</p>
                    <a href="#" class="cd-link">مشاهده همه</a>
                </div>
                <?php $__empty_1 = true; $__currentLoopData = $bookmarkedProviders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="cd-row">
                    <img src="<?php echo e(asset('images/default-pfp.png')); ?>" class="cd-row-avatar" alt="<?php echo e($provider->first_name); ?>">
                    <div style="min-width:0">
                        <p class="cd-row-name"><?php echo e($provider->first_name); ?> <?php echo e($provider->last_name); ?></p>
                        <p class="cd-row-sub"><?php echo e($provider->expertDetail->specialty ?? 'Provider'); ?></p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p style="font-size:14px;color:#6B7280;padding:8px 0;">هنوز بوکمارکی ندارید.</p>
                <?php endif; ?>
            </div>

            <div class="cd-card">
                <div class="cd-card-head">
                    <p class="cd-card-title">پیام‌ها</p>
                    <a href="#" class="cd-link">مشاهده همه</a>
                </div>
                <?php $__empty_1 = true; $__currentLoopData = $recentMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="cd-msg">
                    <div class="cd-msg-top">
                        <p class="cd-msg-name">
                            <?php echo e($message->sender->first_name ?? 'User'); ?>

                            <?php if($message->status == 1): ?>
                            <span class="cd-msg-unread"></span>
                            <?php endif; ?>
                        </p>
                    </div>
                    <p class="cd-msg-text"><?php echo e($message->message); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p style="font-size:14px;color:#6B7280;padding:8px 0;">هنوز پیامی ندارید.</p>
                <?php endif; ?>
            </div>

        </div>
    </div>

    
    <div class="cd-card" id="profile-form" style="margin-top:250px;">
        <div class="cd-card-head">
            <p class="cd-card-title">ویرایش اطلاعات پروفایل</p>
        </div>

        <?php if(session('success')): ?>
        <div class="cd-alert cd-alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(route('customer.profile.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>

            <div class="cd-form-grid">

                <div class="cd-field">
                    <label class="cd-label" for="username">نام کاربری</label>
                    <input type="text" id="username" name="username" class="cd-input"
                        value="<?php echo e(old('username', $user->username)); ?>">
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="cd-error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="cd-field">
                    <label class="cd-label" for="contact_number">شماره تماس</label>
                    <input type="text" id="contact_number" name="contact_number" class="cd-input"
                        value="<?php echo e(old('contact_number', $user->contact_number)); ?>">
                    <?php $__errorArgs = ['contact_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="cd-error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="cd-field">
                    <label class="cd-label" for="first_name">نام</label>
                    <input type="text" id="first_name" name="first_name" class="cd-input"
                        value="<?php echo e(old('first_name', $user->first_name)); ?>">
                    <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="cd-error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="cd-field">
                    <label class="cd-label" for="last_name">نام خانوادگی</label>
                    <input type="text" id="last_name" name="last_name" class="cd-input"
                        value="<?php echo e(old('last_name', $user->last_name)); ?>">
                    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="cd-error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                <div class="cd-field">
                    <label class="cd-label" for="password">رمز عبور جدید</label>
                    <input type="password" id="password" name="password" class="cd-input" placeholder="خالی بگذارید تا تغییر نکند">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="cd-error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="cd-field">
                    <label class="cd-label" for="date_of_birth">تاریخ تولد</label>
                    <input type="date" id="date_of_birth" name="date_of_birth" class="cd-input"
                        value="<?php echo e(old('date_of_birth', $user->date_of_birth?->format('Y-m-d'))); ?>">
                    <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="cd-error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="cd-field">
                    <label class="cd-label" for="password_confirmation">تکرار رمز عبور جدید</label>
                    <input type="password" id="password_confirmation" name="password_confirmation" class="cd-input">
                </div>

            </div>

            <button type="submit" class="cd-btn" style="margin-top:20px;border:none;cursor:pointer;">ذخیره تغییرات</button>
        </form>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/rbt/Documents/0.Daneshgah/Term (8)/Laravel/toolbox/resources/views/dashboard/customer.blade.php ENDPATH**/ ?>