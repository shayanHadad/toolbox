<?php $__env->startSection('title', 'پیام‌های من | جعبه‌ابزار'); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/experts.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<section class="categories experts-section">
    <div class="container">

        <h1 class="expert-section-title" style="margin-bottom:20px;">پیام‌های من</h1>

        <div class="t-card messages-list-card">

            <?php $__empty_1 = true; $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('messages.show', $conversation->partner)); ?>" class="conversation-row">

                    <span class="expert-avatar" style="background-image:url('<?php echo e(asset($conversation->partner->role == 2 ? 'images/expert.png' : 'images/default-pfp.png')); ?>')"></span>

                    <div style="min-width:0;">
                        <p class="conversation-name">
                            <?php echo e(trim($conversation->partner->first_name . ' ' . $conversation->partner->last_name)); ?>

                        </p>
                        <p class="conversation-preview">
                            <?php echo e(\Illuminate\Support\Str::limit($conversation->lastMessage->message ?? '', 60)); ?>

                        </p>
                    </div>

                    <div class="conversation-meta">
                        <span class="conversation-time">
                            <?php echo e($conversation->lastMessage?->created_at?->format('Y-m-d H:i')); ?>

                        </span>
                        <?php if($conversation->unreadCount > 0): ?>
                            <span class="conversation-unread"><?php echo e($conversation->unreadCount); ?></span>
                        <?php endif; ?>
                    </div>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="t-text">هنوز هیچ مکالمه‌ای شروع نکردی.</p>
            <?php endif; ?>

        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/rbt/Documents/0.Daneshgah/Term (8)/Laravel/toolbox/resources/views/messages/index.blade.php ENDPATH**/ ?>