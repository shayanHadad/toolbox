<?php $__env->startSection('title', 'Toolbox'); ?>

<?php $__env->startSection('content'); ?>

<section class="hero">

    <div class="container hero-content">

        <span class="hero-eyebrow"><span class="dot"></span> همیشه همراه شما </span>

        <h1><em>جعبه‌ابزار</em>، شامل هر خدماتی که نیاز داری</h1>

        <p>یافتن سریع خدمات مورد نیاز در هر زمان و هر مکان با کمک جعبه‌ابزار.</p>

        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="جعبه‌ابزار" class="hero-logo">

        <div class="pegboard">
            <div class="pegboard-rail"></div>
            <div class="pegboard-list">
                <a class="peg-item" href="#work-categories">
                    <span class="peg-dot"></span>
                    <span class="peg-chip"><span class="tag">CATEGORIES</span> دسته بند‌ی‌ خدمات</span>
                </a>
                <a class="peg-item" href="#images">
                    <span class="peg-dot"></span>
                    <span class="peg-chip"><span class="tag">PICTURES</span> عکس‌های منتخب</span>
                </a>
                <a class="peg-item" href="#comments">
                    <span class="peg-dot"></span>
                    <span class="peg-chip"><span class="tag">COMMENTS</span> نظرات کاربران</span>
                </a>
            </div>
        </div>



        <div class="hero-glow-cards">


            <div class="hero-cta-row">

                <button type="button" class="spin-btn" onclick="location.href='<?php echo e(url('/experts')); ?>'">
                    <span>افراد متخصص </span>
                </button>

                <button type="button" class="spin-btn" onclick="location.href='<?php echo e(url('/companies')); ?>'">
                    <span>شرکت‌های خدماتی </span>
                </button>

            </div>
</section>


<section class="categories" id="work-categories">
    <div class="container">

        <div class="section-head">
            <span class="hero-eyebrow"><span class="dot"></span> دسته بندی خدمات</span>
            <h2>دریافت خدمات حرفه‌ای هر کار توی بخش خودش</h2>
            <p>برای دسترسی راحت‌تر می‌تونید بخش مورد نظرتون رو انتخاب کنید.</p>
        </div>

        <div class="tc-grid">

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="tool-card">
                <div class="tc-canvas" onclick="location.href='<?php echo e(url('categories/' . $cat->url)); ?>'">
                    <?php for($i = 0; $i < 25; $i++): ?>
                        <div class="tc-tracker">
                </div>
                <?php endfor; ?>

                <a href="<?php echo e(url('categories/' . $cat->url)); ?>" class="tc-face">
                    <span class="tc-overlay"></span>
                    <span class="tc-body">
                        <span class="tc-dot"></span>
                        <span class="tc-title"><?php echo e($cat['category_name']); ?></span>
                        <span class="tc-desc">دسترسی سریع به بهترین متخصص‌ها و شرکت‌های این حوزه</span>
                        <span class="tc-cta">مشاهده خدمات <i class="tc-arrow">←</i></span>
                    </span>
                </a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    </div>
</section>


<div class="section-head" style="margin-top: 100px;" id="images">
    <span class=" hero-eyebrow"><span class="dot"></span> دسته بندی خدمات</span>
</div>
<div class="slideshow" id="toolbox-slideshow" style="margin-top: 10px;">


    <div class="slide is-active">
        <div class="slide-media" style="background-image:url('<?php echo e(asset('images/slide1.jpeg')); ?>')"></div>
        <div class="slide-overlay"></div>
        <div class="slide-copy">
            <span>اسباب کشی</span>
            <h3> دیگه اسباب کشی کار سختی نیست!!! </h3>
            <p>با کمک کارمندان و افراد متخصص دیگه نگران اسباب‌کشی نباشید.</p>
        </div>
    </div>

    <div class="slide">
        <div class="slide-media" style="background-image:url('<?php echo e(asset('images/slide2.jpg')); ?>')"></div>
        <div class="slide-overlay"></div>
        <div class="slide-copy">
            <span>تعمیرات خانگی</span>
            <h3>میتونی برای تعمیر هر وسیله‌ای از ما کمک بخوای </h3>
            <p>متخصصین ما میتونن هرچیزی رو تعمیر کنن.</p>
        </div>
    </div>

    <div class="slide">
        <div class="slide-media" style="background-image:url('<?php echo e(asset('images/slide3.jpeg')); ?>')"></div>
        <div class="slide-overlay"></div>
        <div class="slide-copy">
            <span>تعمیرات ماشین</span>
            <h3> تعمیرات ماشین در محل.</h3>
            <p>حتی توی جاده هم اگر ماشین خراب بشه دیگه نیاز نیست نگران باشی.</p>
        </div>
    </div>

    <div class="slide-arrows">
        <button type="button" class="slide-arrow" data-dir="prev" aria-label="اسلاید قبلی">‹</button>
        <button type="button" class="slide-arrow" data-dir="next" aria-label="اسلاید بعدی">›</button>
    </div>

    <div class="slide-dots"></div>

</div>
</section>


<section class="testimonials" id="comments">
    <div class="container">

        <div class="section-head">
            <span class="hero-eyebrow"><span class="dot"></span> نظر کاربران</span>
            <h2>نظرات کسایی که از جعبه‌ابزار استفاده کردن</h2>
        </div>

        <div class="t-grid">

            <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="t-card">
                <span class="t-quote-mark">”</span>
                <div class="t-stars">
                    <?php for($i = 0; $i < 5; $i++): ?>
                        <?php echo e($i < $order->rating ? '★' : '☆'); ?>

                        <?php endfor; ?>
                        </div>
                        <p class="t-text"><?php echo e($order->comment); ?></p>
                        <div class="t-person">
                            <span class="t-avatar" style="background-image:url('<?php echo e(asset('images/default-pfp.png')); ?>')"></span>
                            <span>
                                <span class="t-name"><?php echo e($order->customer->first_name ?? 'کاربر'); ?> <?php echo e($order->customer->last_name ?? ''); ?></span><br>
                                <span class="t-role"><?php echo e($order->provider->expertDetail->category->category_name ?? 'مشتری جعبه‌ابزار'); ?></span>
                            </span>
                        </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p style="text-align:center;color:var(--text-light);grid-column:1/-1;">
                    هنوز نظری ثبت نشده.
                </p>
                <?php endif; ?>

            </div>
        </div>
</section>


<section class="cta-bar">
    <div class="container">
        <div class="cta-box">
            <h2>اگر سوالی داری میتونی با ما در ارتباط باشی.</h2>
            <div class="cta-links">
                <a href="<?php echo e(url('/register')); ?>" class="btn btn-primary">ثبت‌نام </a>
                <a href="<?php echo e(url('/login')); ?>" class="btn btn-outline">ورود </a>
                <a href="<?php echo e(url('/about')); ?>" class="btn btn-outline">درباره ما</a>
                <a href="<?php echo e(url('/contact')); ?>" class="btn btn-outline">تماس با ما</a>
            </div>
        </div>
    </div>
</section>


<script>
    (function() {
        const root = document.getElementById('toolbox-slideshow');
        if (!root) return;

        const slides = [...root.querySelectorAll('.slide')];
        const dotsWrap = root.querySelector('.slide-dots');
        let index = 0;
        let timer;

        slides.forEach((_, i) => {
            const dot = document.createElement('button');
            dot.type = 'button';
            dot.className = 'slide-dot' + (i === 0 ? ' is-active' : '');
            dot.setAttribute('aria-label', 'برو به اسلاید ' + (i + 1));
            dot.addEventListener('click', () => go(i));
            dotsWrap.appendChild(dot);
        });

        const dots = [...dotsWrap.querySelectorAll('.slide-dot')];

        function go(i) {
            slides[index].classList.remove('is-active');
            dots[index].classList.remove('is-active');
            index = (i + slides.length) % slides.length;
            slides[index].classList.add('is-active');
            dots[index].classList.add('is-active');
            restart();
        }

        function restart() {
            clearInterval(timer);
            timer = setInterval(() => go(index + 1), 5000);
        }

        root.querySelector('[data-dir="next"]').addEventListener('click', () => go(index + 1));
        root.querySelector('[data-dir="prev"]').addEventListener('click', () => go(index - 1));
        root.addEventListener('mouseenter', () => clearInterval(timer));
        root.addEventListener('mouseleave', restart);

        restart();
    })();
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/rbt/Documents/0.Daneshgah/Term (8)/Laravel/toolbox/resources/views/home.blade.php ENDPATH**/ ?>